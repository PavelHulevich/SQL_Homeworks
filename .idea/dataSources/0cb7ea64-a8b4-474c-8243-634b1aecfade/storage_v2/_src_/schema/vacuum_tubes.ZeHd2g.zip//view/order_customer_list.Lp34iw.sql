create definer = root@localhost view order_customer_list as
select concat(`ts`.`tube_size_name`, '/', `tt`.`tube_type_name`, '-', `o`.`tube_volume`) AS `Наименование пробирки`,
       concat(`o`.`quantity`, 'шт.')                                                     AS `Количество`,
       `o`.`order_date`                                                                  AS `Дата заказа`,
       concat(`cn`.`customer_name_name`, '. ', `cc`.`customer_city_name`)                AS `Заказчик`
from ((((((`vacuum_tubes`.`order_customer` `oc` join `vacuum_tubes`.`customer` `c`
           on ((`oc`.`order_customer_customer` = `c`.`id`))) join `vacuum_tubes`.`customer_city` `cc`
          on ((`c`.`city` = `cc`.`customer_city_id`))) join `vacuum_tubes`.`customer_name` `cn`
         on ((`c`.`name` = `cn`.`customer_name_id`))) join `vacuum_tubes`.`orders` `o`
        on ((`oc`.`order_customer_order` = `o`.`order_Id`))) join `vacuum_tubes`.`tube_size` `ts`
       on ((`o`.`tube_size` = `ts`.`tube_size_id`))) join `vacuum_tubes`.`tube_type` `tt`
      on ((`o`.`tube_type` = `tt`.`tube_type_id`)));

