create definer = root@localhost trigger before_insert_customer_city
    before insert
    on customer_city
    for each row
begin
    if NEW.customer_city_name is not null and length(NEW.customer_city_name) > 0 then  -- если вводимое название не нулевое и не null
        set NEW.customer_city_name = concat(                 -- то из вводимого имени формируем имя нужного вида.
                UPPER(LEFT(NEW.customer_city_name, 1)),      -- Первую букву делаем прописной.
                LOWER(substring(NEW.customer_city_name, 2))  -- Остальные начиная со второй делаем строчными
                            );
    end if;
end;

