create definer = root@localhost view production_list as
select concat(`ts`.`tube_size_name`, '/', `tt`.`tube_type_name`, '-',
              `p`.`production_tube_volume`)     AS `Наименование пробирки`,
       concat(`p`.`production_quantity`, 'шт.') AS `Количество`,
       `p`.`production_change_date`             AS `Дата изменения партии`,
       `p`.`production_status`                  AS `Статус партии`
from ((`final_project_hulevich_vacuum_tubes`.`production` `p` join `final_project_hulevich_vacuum_tubes`.`tube_size` `ts`
       on ((`ts`.`tube_size_id` = `p`.`production_tube_size`))) join `final_project_hulevich_vacuum_tubes`.`tube_type` `tt`
      on ((`tt`.`tube_type_id` = `p`.`production_tube_type`)));

