create definer = root@localhost trigger after_insert_citys
    after insert
    on citys
    for each row
begin
            update citys
            set change_date = now()
            where city_id =  NEW.city_id;
        end;

