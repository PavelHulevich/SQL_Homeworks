create definer = root@localhost view citys_list as
select `citys_users`.`citys`.`city_name`                                 AS `city_name`,
       `citys_users`.`citys`.`city_population`                           AS `city_population`,
       if(`citys_users`.`citys`.`city_capital`, 'Столица', 'Не столица') AS `Столичный город`,
       `citys_users`.`citys`.`city_district`                             AS `Количество районов`
from `citys_users`.`citys`;

